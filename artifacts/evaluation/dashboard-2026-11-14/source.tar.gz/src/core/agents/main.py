from __future__ import annotations

import logging
import os
import re
import inspect
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, Literal

from dotenv import load_dotenv
from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from pydantic import BaseModel, ConfigDict, Field, field_validator

from core.sql_agent.analytics_agent import AnalyticsAgent
from core.agents.dashboard_agent import InventoryDashboardAgent
from core.agents.intent_classifier import IntentClassifier
from core.agents.knowledge_agent import KnowledgeAgent
from core.agents.report_agent import ReportAgent
from core.agents.router import AgentRouter
from core.sql_agent.agent import AnalyticsPermissionDenied, SQLAnalyticsAgent
from core.sql_agent.assistant_endpoint import run_sql_assistant
from core.database.commerce_repository import LazyCommerceRepository
from core.models.agents import AgentRequest, AgentResult, VerifiedIdentity, validate_chat_metadata


LOGGER = logging.getLogger(__name__)
REPO_ROOT = Path(__file__).resolve().parents[2]


def _local_development_identity() -> VerifiedIdentity | None:
    """Return an explicitly opted-in local identity; never use this in production."""
    if os.getenv("APP_ENV", "").casefold() != "development":
        return None
    if os.getenv("ALLOW_DEV_ANALYTICS", "").casefold() != "true":
        return None
    subject = os.getenv("DEV_ANALYTICS_IDENTITY", "").strip()
    if not subject:
        return None
    return VerifiedIdentity(subject=subject, permissions={"analytics:read", "documents:read"}, document_roles={"admin"})


class _FallbackClassifier:
    """Use the local deterministic classifier for the chat entrypoint."""

    @staticmethod
    def classify(question: str):
        intent = IntentClassifier.fallback(question)
        text = question.casefold()
        if intent.needs_knowledge and any(term in text for term in
                ("chính sách", "quy trình", "tài liệu", "policy", "procedure", "document")) and not (
                re.search(r"\b(?:19|20)\d{2}\b", text) or
                any(term in text for term in ("bao nhiêu", "so sánh", "tính toán", "thống kê"))):
            return intent.model_copy(update={"intent": "knowledge", "needs_sql": False,
                                             "needs_knowledge": True})
        return intent


class _LazyKnowledgeAgent:
    def __init__(self) -> None:
        self.agent: KnowledgeAgent | None = None

    async def run(self, request: AgentRequest) -> AgentResult:
        if self.agent is None:
            self.agent = KnowledgeAgent()
        return await self.agent.run(request)

    async def retrieve(self, request: AgentRequest):
        if self.agent is None:
            self.agent = KnowledgeAgent()
        return await self.agent.retrieve(request)

    async def retrieve_metric_definition(self, request: AgentRequest, metric_name: str):
        if self.agent is None:
            self.agent = KnowledgeAgent()
        return await self.agent.retrieve_metric_definition(request, metric_name)

    async def close(self) -> None:
        if self.agent is not None:
            await self.agent.close()


class _UnsupportedRoute:
    async def run(self, _request: AgentRequest) -> AgentResult:
        return AgentResult(answer="Loại yêu cầu này chưa được hỗ trợ trong trò chuyện.",
                           agent="unsupported", metadata={"ok": False})


class ChatRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    question: str = Field(min_length=1, max_length=2_000)
    agent_mode: Literal["auto", "knowledge", "sql", "dashboard", "agentic", "report"] = "auto"
    retrieval_method: Literal["dense", "bm25", "hybrid", "parent", "translated_hybrid", "translated_hybrid_rerank"] = "translated_hybrid_rerank"
    conversation_id: str | None = Field(default=None, max_length=128)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("question")
    @classmethod
    def normalize_question(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("Câu hỏi không được để trống")
        return normalized

    @field_validator("metadata")
    @classmethod
    def bound_metadata(cls, value: dict[str, Any]) -> dict[str, Any]:
        return validate_chat_metadata(value)


class SQLAssistantRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    question: str = Field(min_length=1, max_length=2_000)
    mode: Literal["draft", "execute"] = "draft"
    sql: str | None = Field(default=None, max_length=20_000)
    parameters: list[Any] = Field(default_factory=list, max_length=32)

    @field_validator("question")
    @classmethod
    def normalize_question(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("Câu hỏi không được để trống")
        return normalized


def create_app(*, chat_agent: Any | None = None, commerce_repository: Any | None = None,
               knowledge_agent: Any | None = None, classifier: Any | None = None,
               identity_resolver: Any | None = None, llm: Any | None = None,
               report_agent: Any | None = None, sql_agent: SQLAnalyticsAgent | None = None) -> FastAPI:
    @asynccontextmanager
    async def lifespan(application: FastAPI) -> AsyncIterator[None]:
        runtime_agent = chat_agent
        runtime_report_agent = report_agent
        owns_agent = runtime_agent is None
        if runtime_agent is None:
            load_dotenv(REPO_ROOT / ".env", override=False)
            repository = commerce_repository or getattr(sql_agent, "repository", None) or LazyCommerceRepository()
            knowledge = knowledge_agent or _LazyKnowledgeAgent()
            runtime_sql_agent = sql_agent or SQLAnalyticsAgent(
                repository, llm=llm, metric_retriever=knowledge.retrieve_metric_definition,
            )
            analytics_agent = AnalyticsAgent(runtime_sql_agent)
            runtime_report_agent = runtime_report_agent or ReportAgent(knowledge, analytics_agent.sql_agent, llm=llm)
            runtime_agent = AgentRouter(
                classifier or _FallbackClassifier(), knowledge, analytics_agent,
                dashboard_agent=InventoryDashboardAgent(repository),
                report_agent=runtime_report_agent,
            )
            if isinstance(runtime_report_agent, ReportAgent):
                runtime_report_agent.source_router = runtime_agent
        else:
            runtime_sql_agent = sql_agent or getattr(
                getattr(runtime_agent, "analytics_agent", None), "sql_agent", None)
        application.state.chat_agent = runtime_agent
        application.state.report_agent = runtime_report_agent
        application.state.sql_agent = runtime_sql_agent
        try:
            yield
        finally:
            if owns_agent:
                await runtime_agent.close()

    application = FastAPI(
        title="Trợ lý tri thức doanh nghiệp",
        version="0.1.0",
        lifespan=lifespan,
    )
    @application.get("/health")
    async def health() -> dict[str, str]:
        return {"status": "ok"}

    @application.post("/api/chat", response_model=AgentResult)
    async def chat(payload: ChatRequest, request: Request) -> AgentResult:
        try:
            identity = None
            if identity_resolver is not None:
                identity = identity_resolver(request)
                if inspect.isawaitable(identity):
                    identity = await identity
            else:
                identity = getattr(request.state, "verified_identity", None)
                if identity is None:
                    identity = _local_development_identity()
            if identity is not None and not isinstance(identity, VerifiedIdentity):
                raise AnalyticsPermissionDenied("Request identity was not verified")
            agent_request = AgentRequest(
                question=payload.question,
                conversation_id=payload.conversation_id,
                metadata={**payload.metadata, "retrieval_method": payload.retrieval_method},
                user_id=identity.subject if identity else None,
                identity=identity,
            )
            chat_agent = request.app.state.chat_agent
            if payload.agent_mode == "auto":
                result = await chat_agent.run(agent_request)
            else:
                result = await chat_agent.run_mode(agent_request, payload.agent_mode)
            return AgentResult.model_validate(result)
        except PermissionError:
            raise HTTPException(
                status_code=403,
                detail="Bạn không có quyền truy cập dữ liệu phân tích.",
            ) from None

    @application.post("/api/sql/assistant", summary="Draft and run an approved schema-aware SQL query")
    async def sql_assistant(payload: SQLAssistantRequest, request: Request) -> dict[str, Any]:
        agent = request.app.state.sql_agent
        if agent is None:
            raise HTTPException(status_code=503, detail="The SQL assistant is not configured")
        if payload.mode == "execute" and not payload.sql:
            raise HTTPException(status_code=422, detail="Provide the SQL draft you reviewed and approved")
        if payload.mode == "draft" and payload.sql is not None:
            raise HTTPException(status_code=422, detail="SQL is accepted only with mode='execute'")
        identity = None
        if identity_resolver is not None:
            identity = identity_resolver(request)
            if inspect.isawaitable(identity):
                identity = await identity
        else:
            identity = getattr(request.state, "verified_identity", None)
            if identity is None:
                identity = _local_development_identity()
        if (not isinstance(identity, VerifiedIdentity)
                or "analytics:read" not in identity.permissions):
            raise HTTPException(status_code=403, detail="Verified analytics:read permission is required")
        try:
            return await run_sql_assistant(agent, payload.question, mode=payload.mode,
                sql=payload.sql, parameters=payload.parameters)
        except PermissionError:
            raise HTTPException(status_code=403, detail="Verified analytics:read permission is required") from None
        except Exception as error:
            LOGGER.exception("SQL assistant request failed")
            raise HTTPException(status_code=422, detail=str(error)) from None

    @application.post("/api/report")
    async def report(request: Request, question: str = Form(...), template: UploadFile | None = File(None),
                     source_mode: Literal["documents", "analytics", "orchestrated", "combined"] = Form("documents"),
                     output_format: Literal["markdown", "docx"] | None = Form(None),
                     template_choice: Literal['uploaded', 'suggested'] | None = Form(None),
                     accept_supported_scope: bool = Form(False),
                     conversation_id: str | None = Form(None, max_length=128)):
        try:
            question = ChatRequest(question=question).question
            identity = None
            if identity_resolver is not None:
                identity = identity_resolver(request)
                if inspect.isawaitable(identity):
                    identity = await identity
            else:
                identity = getattr(request.state, "verified_identity", None)
                if identity is None:
                    identity = _local_development_identity()
            if not isinstance(identity, VerifiedIdentity):
                raise AnalyticsPermissionDenied("A verified identity is required")
            from core.reports.sources import authorize_sources
            from core.reports.http import report_response
            agent_request = AgentRequest(question=question.strip(), user_id=identity.subject, identity=identity,
                                         conversation_id=conversation_id)
            authorize_sources(agent_request, source_mode)
            filename = Path(template.filename or "").name if template else None
            extension = Path(filename).suffix.casefold() if filename else None
            if extension == ".docx":
                if template.content_type != "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
                    raise HTTPException(status_code=422, detail="DOCX content type is required")
            elif extension == ".md":
                if template.content_type not in {"text/markdown", "text/plain", "application/octet-stream"}:
                    raise HTTPException(status_code=422, detail="Markdown content type is required")
            elif template is not None:
                raise HTTPException(status_code=422, detail="Template must be a DOCX or Markdown file")
            content = await template.read(10 * 1024 * 1024 + 1) if template else None
            result, payload, media_type = await request.app.state.report_agent.generate_from_template(
                agent_request, filename, content, source_mode=source_mode, output_format=output_format,
                template_choice=template_choice, accept_supported_scope=accept_supported_scope,
            )
            return report_response(result, payload, media_type)
        except PermissionError:
            raise HTTPException(status_code=403, detail="Verified permission for the selected report sources is required") from None
        except HTTPException:
            raise
        except ValueError as error:
            raise HTTPException(status_code=422, detail=str(error)) from None
        except Exception as error:
            LOGGER.error("api_report_failed error_type=%s", type(error).__name__)
            raise HTTPException(status_code=503, detail="Report generation is temporarily unavailable") from None
        except Exception as error:
            LOGGER.error("api_chat_failed error_type=%s", type(error).__name__)
            raise HTTPException(
                status_code=503,
                detail="Hệ thống tạm thời không thể xử lý yêu cầu.",
            ) from None

    return application


app = create_app()
