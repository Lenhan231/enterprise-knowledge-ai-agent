"""Table-aware chunking helpers."""
