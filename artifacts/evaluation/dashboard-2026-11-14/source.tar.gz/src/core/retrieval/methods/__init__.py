"""Independent retrieval method implementations."""
