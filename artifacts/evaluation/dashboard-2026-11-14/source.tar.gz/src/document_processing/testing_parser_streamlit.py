"""Single-user local UI for the Docling document-processing store."""

from __future__ import annotations

import hashlib
from io import BytesIO
import json
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import streamlit as st
from PIL import Image, ImageDraw

from document_processing.document_processor import DocumentProcessor, SUPPORTED_FORMATS
from document_processing.element_taxonomy import normalize_element_label


PACKAGE_DIR = Path(__file__).resolve().parent
STORE_DIR = Path(os.environ.get("DOCUMENT_PROCESSING_STORE", PACKAGE_DIR / ".owner_store")).expanduser()
MAX_UPLOAD_BYTES = 50 * 1024 * 1024


def _load_runs() -> list[dict[str, Any]]:
    runs = []
    if not STORE_DIR.exists():
        return runs
    for manifest_path in STORE_DIR.glob("*/manifest.json"):
        try:
            runs.append(json.loads(manifest_path.read_text(encoding="utf-8")))
        except (OSError, json.JSONDecodeError):
            continue
    return sorted(runs, key=lambda run: run.get("processed_at", ""), reverse=True)


def _pdf_page_count(content: bytes) -> int:
    import fitz

    with fitz.open(stream=content, filetype="pdf") as pdf:
        return pdf.page_count


def _parse_selected_pages(value: str, page_count: int) -> list[int] | None:
    if not value.strip():
        return None
    try:
        pages = sorted({int(part.strip()) for part in value.split(",")})
    except ValueError as error:
        raise ValueError("Enter page numbers separated by commas, for example 2, 5, 9.") from error
    if not pages or pages[0] < 1 or pages[-1] > page_count:
        raise ValueError(f"Page numbers must be between 1 and {page_count}.")
    return pages


def _subset_pdf(content: bytes, selected_pages: list[int]) -> bytes:
    import fitz

    with fitz.open(stream=content, filetype="pdf") as source_pdf:
        subset = fitz.open()
        try:
            for page_number in selected_pages:
                subset.insert_pdf(source_pdf, from_page=page_number - 1, to_page=page_number - 1)
            return subset.tobytes(garbage=4, deflate=True)
        finally:
            subset.close()


def _remap_selected_page_numbers(output: dict[str, Any], selected_pages: list[int]) -> None:
    def original_page_number(page_number: Any) -> int | None:
        try:
            subset_page = int(page_number)
            return selected_pages[subset_page - 1] if 1 <= subset_page <= len(selected_pages) else None
        except (TypeError, ValueError):
            return None

    for element in output.get("elements", []):
        metadata = element.get("metadata") or {}
        if metadata.get("page_number") is not None:
            metadata["page_number"] = original_page_number(metadata["page_number"])
    for table in output.get("tables", []):
        if table.get("page_number") is not None:
            table["page_number"] = original_page_number(table["page_number"])
        metadata = table.get("metadata") or {}
        if metadata.get("page_number") is not None:
            metadata["page_number"] = original_page_number(metadata["page_number"])
    for extraction_name in ("invoice_extraction", "image_caption_extraction"):
        for page in (output.get(extraction_name) or {}).get("pages", []):
            page["page_number"] = original_page_number(page.get("page_number"))
    for detection in output.get("layout_detections", []):
        detection["page_number"] = original_page_number(detection.get("page_number"))
    for key in ("page_previews", "page_sizes"):
        if key in output:
            output[key] = {
                str(selected_pages[int(page_number) - 1]): value
                for page_number, value in output[key].items()
                if 1 <= int(page_number) <= len(selected_pages)
            }


def _normalize_saved_output(output: dict[str, Any]) -> dict[str, Any]:
    """Normalize saved output and derive title links from stored layout boxes."""
    for element in output.get("elements", []):
        metadata = element.setdefault("metadata", {})
        metadata.pop("word_style", None)
        metadata.pop("word_style_id", None)
        label = normalize_element_label(
            metadata.get("element_type") or metadata.get("layout_type") or element.get("element_type")
        )
        metadata["element_type"] = label
        metadata["layout_type"] = label
        if "element_type" in element:
            element["element_type"] = label
    for table in output.get("tables", []):
        metadata = table.setdefault("metadata", {})
        metadata.pop("word_style", None)
        metadata.pop("word_style_id", None)
        metadata.update({"element_type": "table", "layout_type": "table"})

    # Older saved runs already contain detector boxes, but predate title links.
    # Derive those links at load time so users can inspect the heuristic without
    # rerunning OCR/layout inference or rewriting the stored result.
    page_sizes = output.get("page_sizes") or {}
    detections = output.get("layout_detections") or []
    if detections and page_sizes:
        from document_processing.docling_adapter.result_mapper import (
            _associate_layout_titles,
            associate_chart_title_regions,
        )

        normalized_sizes = {
            int(page_number): (float(size["width"]), float(size["height"]))
            for page_number, size in page_sizes.items()
            if size.get("width") is not None and size.get("height") is not None
        }
        _associate_layout_titles(
            detections,
            output.get("elements", []),
            output.get("tables", []),
            normalized_sizes,
        )
        chart_elements = []
        chart_regions = []
        for element in output.get("elements", []):
            metadata = element.get("metadata") or {}
            if (
                normalize_element_label(metadata.get("element_type")) == "chart"
                and metadata.get("bbox")
                and metadata.get("page_number") is not None
            ):
                chart_elements.append(element)
                chart_regions.append({
                    "page_no": metadata["page_number"],
                    "bbox": metadata["bbox"],
                })
        associate_chart_title_regions(chart_regions, detections, normalized_sizes)
        seen_chart_groups = set()
        for element, chart in zip(chart_elements, chart_regions):
            if not chart.get("title_bbox"):
                continue
            metadata = element.setdefault("metadata", {})
            if "chart_recognition_bbox" not in metadata:
                planned_metadata = {
                    "chart_recognition_bbox": chart["recognition_bbox"],
                    "chart_title_bbox": chart["title_bbox"],
                    "chart_title_match_score": chart["title_match_score"],
                    "chart_recognition_input": "planned_chart_and_title_union_crop",
                }
                group_id = chart.get("recognition_group_id")
                if group_id:
                    planned_metadata.update({
                        "chart_recognition_group_id": group_id,
                        "chart_member_bboxes": chart["recognition_group_member_bboxes"],
                        "chart_recognition_group_lead": group_id not in seen_chart_groups,
                    })
                    seen_chart_groups.add(group_id)
                metadata.update(planned_metadata)
    return output


def _parser_output_row_preview(
    selected_id: str,
    filename: str,
    source_sha256: str,
    output: dict[str, Any],
) -> dict[str, Any]:
    """Build locally the JSONB payload written by the Supabase upload button."""
    normalized_elements = []
    for element in output.get("elements", []):
        normalized_element = dict(element)
        metadata = dict(element.get("metadata") or {})
        metadata.pop("word_style", None)
        metadata.pop("word_style_id", None)
        element_type = normalize_element_label(
            metadata.get("element_type") or metadata.get("layout_type") or element.get("element_type")
        )
        metadata.update({"element_type": element_type, "layout_type": element_type})
        normalized_element["metadata"] = metadata
        if "element_type" in normalized_element:
            normalized_element["element_type"] = element_type
        normalized_elements.append(normalized_element)

    parser_metadata = output.get("metadata") or {}
    return {
        "document_id": f"PARSER-{selected_id}",
        "pipeline_id": str(parser_metadata.get("pipeline_id") or parser_metadata.get("parser_engine") or "docling"),
        "elements": normalized_elements,
        "tables": output.get("tables", []),
        "document_metadata": {
            **parser_metadata,
            **({"invoice_extraction": output["invoice_extraction"]} if output.get("invoice_extraction") else {}),
            **({"image_caption_extraction": output["image_caption_extraction"]} if output.get("image_caption_extraction") else {}),
            "filename": filename,
            "source_sha256": source_sha256,
            "local_parser_run_id": selected_id,
            "chunking_applied": False,
            "embeddings_created": False,
        },
    }


def _page_numbers(run_dir: Path) -> list[int]:
    return sorted(
        int(path.stem.removeprefix("page-"))
        for path in run_dir.glob("page-*.png")
        if path.stem.removeprefix("page-").isdigit()
    )


def _table_display_name(table: dict[str, Any], index: int) -> str:
    metadata = table.get("metadata") or {}
    context = table.get("context") or {}
    title = (
        table.get("table_name")
        or context.get("table_title")
        or context.get("table_name")
        or metadata.get("table_name")
        or metadata.get("table_title")
    )
    if title and str(title).strip():
        return str(title).strip()
    columns = [str(column).strip() for column in (table.get("columns") or []) if str(column).strip()]
    return " · ".join(columns[:3]) or f"Table {index}"


def _page_preview(run_dir: Path, page_number: int) -> bytes | None:
    preview_path = run_dir / f"page-{page_number}.png"
    return preview_path.read_bytes() if preview_path.is_file() else None


def _page_preview_with_boxes(
    preview: bytes,
    elements: list[dict[str, Any]],
    tables: list[dict[str, Any]],
    page_size: dict[str, float] | None,
    *,
    default_origin: str,
    layout_detections: list[dict[str, Any]] | None = None,
) -> bytes:
    image = Image.open(BytesIO(preview)).convert("RGB")
    draw = ImageDraw.Draw(image)
    page_width = float((page_size or {}).get("width") or image.width)
    page_height = float((page_size or {}).get("height") or image.height)
    scale_x, scale_y = image.width / page_width, image.height / page_height

    def draw_bbox(metadata: dict[str, Any], color: str, label: str) -> None:
        bbox = metadata.get("bbox")
        if not isinstance(bbox, list) or len(bbox) != 4:
            return
        try:
            left, top_or_bottom, right, bottom_or_top = map(float, bbox)
        except (TypeError, ValueError):
            return
        origin = str(metadata.get("bbox_coordinate_origin") or default_origin).upper()
        if metadata.get("bbox_coordinate_system") == "docling_page_coordinate":
            origin = "TOPLEFT"
        if origin == "BOTTOMLEFT":
            top, bottom = page_height - bottom_or_top, page_height - top_or_bottom
        else:
            top, bottom = top_or_bottom, bottom_or_top
        xyxy = (
            round(left * scale_x),
            round(top * scale_y),
            round(right * scale_x),
            round(bottom * scale_y),
        )
        draw.rectangle(xyxy, outline=color, width=max(2, image.width // 900))
        if label:
            draw.text((xyxy[0] + 2, max(0, xyxy[1] - 14)), label, fill=color)

    for element in elements:
        metadata = element.get("metadata") or {}
        kind = normalize_element_label(metadata.get("element_type") or metadata.get("layout_type") or metadata.get("docling_label"))
        color = {
            "title": "#ff9b69",
            "title_table": "#e879f9",
            "text": "#58aeff",
            "footnote": "#f472b6",
            "document_index": "#fbbf24",
            "formula": "#c084fc",
            "figure": "#ffcf5c",
            "chart": "#fb923c",
            "seal": "#fb7185",
            "page_header": "#a78bfa",
            "page_footer": "#f472b6",
            "table": "#65d99b",
        }[kind]
        draw_bbox(metadata, color, kind)
        if (
            metadata.get("chart_title_bbox")
            and metadata.get("chart_recognition_bbox")
            and metadata.get("chart_recognition_bbox") != metadata.get("bbox")
            and metadata.get("chart_recognition_group_lead", True)
        ):
            crop_label = (
                "VL crop"
                if metadata.get("chart_recognition_input") == "chart_and_matched_title_union_crop"
                else "VL crop (planned)"
            )
            draw_bbox(
                {**metadata, "bbox": metadata["chart_recognition_bbox"]},
                "#facc15",
                crop_label,
            )
    for table in tables:
        draw_bbox(table.get("metadata") or {}, "#65d99b", "table")
    layout_colors = {
        "paragraph_title": "#f97316", "image": "#facc15", "text": "#38bdf8",
        "number": "#a78bfa", "abstract": "#22c55e", "content": "#06b6d4",
        "figure_title": "#e879f9", "formula": "#c084fc", "table": "#34d399",
        "reference": "#fb7185", "doc_title": "#fb923c", "footnote": "#f472b6",
        "header": "#818cf8", "algorithm": "#2dd4bf", "footer": "#f43f5e",
        "seal": "#ef4444", "chart": "#f97316", "formula_number": "#d946ef",
        "aside_text": "#84cc16", "reference_content": "#14b8a6",
    }
    for detection in layout_detections or []:
        label = str(detection.get("label", "unknown"))
        color = layout_colors.get(label, "#f8fafc")
        target = detection.get("associated_target") or {}
        matched = (
            f" -> {target.get('target_type')}#{target.get('target_index')}"
            if target else ""
        )
        draw_bbox(detection, color, f"{label} {float(detection.get('score', 0.0)):.2f}{matched}")

    output = BytesIO()
    image.save(output, format="PNG")
    return output.getvalue()


def _process_upload(
    filename: str,
    content: bytes,
    *,
    intent: str,
    ocr_engine: str,
    language: str,
    device: str,
    ocr_enabled: bool,
    table_structure: bool,
    chart_recognition: bool,
    num_threads: int,
    selected_pages: list[int] | None = None,
) -> dict[str, Any]:
    run_id = uuid.uuid4().hex
    run_dir = STORE_DIR / run_id
    STORE_DIR.mkdir(parents=True, exist_ok=True, mode=0o700)
    STORE_DIR.chmod(0o700)
    run_dir.mkdir(mode=0o700, exist_ok=False)
    try:
        source_path = run_dir / "source"
        source_path.write_bytes(content)
        source_path.chmod(0o600)
        config = {
            "parser_engine": "docling",
            "intent": intent,
            "docling_device": device,
            "docling_ocr": ocr_enabled,
            "docling_ocr_engine": ocr_engine,
            "docling_ocr_language": language,
            "docling_table_structure": table_structure,
            "docling_chart_recognition": chart_recognition,
            "docling_num_threads": num_threads,
            "docling_page_images": True,
            "selected_source_pages": selected_pages,
        }
        metadata = {
            "source_type": "local_owner_store",
            "source_sha256": hashlib.sha256(content).hexdigest(),
        }
        processing_content = _subset_pdf(content, selected_pages) if selected_pages else content
        output = DocumentProcessor(config).process(filename, processing_content, metadata)
        if selected_pages:
            _remap_selected_page_numbers(output, selected_pages)
            output.setdefault("metadata", {})["selected_source_pages"] = selected_pages
        page_previews = output.pop("page_previews", {})
        for page_number, image_bytes in page_previews.items():
            preview_path = run_dir / f"page-{int(page_number)}.png"
            preview_path.write_bytes(image_bytes)
            preview_path.chmod(0o600)
        output_text = json.dumps(output, ensure_ascii=False, indent=2, default=str)
        output_path = run_dir / "output.json"
        output_path.write_text(output_text, encoding="utf-8")
        output_path.chmod(0o600)
        manifest = {
            "run_id": run_id,
            "filename": filename,
            "processed_at": datetime.now(timezone.utc).isoformat(),
            "source_sha256": metadata["source_sha256"],
            "element_count": len(output.get("elements", [])),
            "table_count": len(output.get("tables", [])),
            "config": config,
        }
        manifest_path = run_dir / "manifest.json"
        manifest_path.write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8",
        )
        manifest_path.chmod(0o600)
        return {"manifest": manifest, "output": output, "output_text": output_text}
    except Exception:
        for path in run_dir.iterdir():
            path.unlink()
        run_dir.rmdir()
        raise


st.set_page_config(page_title="Document store", layout="wide")
st.markdown(
    """
    <style>
    [data-testid="stAppViewContainer"] .main .block-container {
        max-width: 1440px;
        padding-top: 2.25rem;
        padding-bottom: 4rem;
    }
    [data-testid="stFileUploader"] section {
        border: 1px dashed rgba(128, 128, 128, 0.55);
        border-radius: 12px;
        padding: 1rem;
    }
    [data-testid="stMetric"] {
        background: var(--secondary-background-color);
        border: 1px solid rgba(128, 128, 128, 0.18);
        border-radius: 12px;
        padding: 0.8rem 1rem;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.caption("PRIVATE DOCUMENT WORKSPACE")
st.title("Document store")
st.markdown("Upload a file, review extracted content, and keep the results on this machine.")

intent = st.radio(
    "Processing intent",
    ["document", "invoice", "image_caption"],
    index=0,
    horizontal=True,
    format_func={
        "document": "General document · current pipeline",
        "invoice": "Invoice · Vintern extraction",
        "image_caption": "Image caption · Vintern",
    }.__getitem__,
    key="processing_intent",
)

upload_column, settings_column = st.columns([1.7, 1], gap="large")
with settings_column:
    with st.container(border=True):
        st.subheader("Processing settings")
        ocr_engine = "vietocr"
        language = "vie+eng"
        ocr_enabled = True
        table_structure = True
        chart_recognition = False
        num_threads = 4
        if intent == "document":
            ocr_engine = st.selectbox(
                "OCR engine",
                ["vietocr", "tesseract"],
                format_func={
                    "vietocr": "VietOCR · benchmark best",
                    "tesseract": "Tesseract",
                }.__getitem__,
                index=0,
            )
            if ocr_engine == "tesseract":
                language = st.selectbox(
                    "OCR languages",
                    ["vie+eng", "vie", "eng"],
                    format_func={
                        "vie+eng": "Vietnamese + English",
                        "vie": "Vietnamese only",
                        "eng": "English only",
                    }.__getitem__,
                )
        device = st.selectbox("Device", ["cpu", "cuda"], format_func={
            "cpu": "CPU",
            "cuda": "NVIDIA CUDA",
        }.__getitem__)
        if intent == "document":
            ocr_enabled = st.selectbox("OCR for images and Office pictures", [True, False], format_func={
                True: "On",
                False: "Off",
            }.__getitem__)
            table_structure = st.selectbox("Table structure recognition", [True, False], format_func={
                True: "On",
                False: "Off",
            }.__getitem__)
            chart_recognition = st.checkbox(
                "Extract chart text with PaddleOCR-VL",
                value=False,
                help="Loads an additional vision-language model and can use several GiB of RAM. Leave off to keep chart regions without generated chart text.",
            )
            num_threads = st.number_input("CPU threads", min_value=1, max_value=16, value=4)
            st.caption("Tables: Accurate mode")
            st.caption("PDF native text is ignored; VietOCR uses detected layout regions and Tesseract uses full-page OCR.")
            st.caption(
                "VietOCR uses RapidOCR line detection + vgg_seq2seq greedy recognition (512 px), "
                "matching the 58-page OCR benchmark."
                if ocr_engine == "vietocr"
                else "Tesseract PSM 6 with the selected languages."
            )
        else:
            st.caption(
                "Vintern reads each page directly and returns invoice fields or a short image caption. "
                "OCR and TableFormer settings do not apply in this mode."
            )

with upload_column:
    with st.container(border=True):
        st.subheader("Add a document")
        st.caption(
            "Intent: invoice extraction · Vintern" if intent == "invoice"
            else "Intent: image caption · Vintern" if intent == "image_caption"
            else "Intent: general document · current Docling pipeline"
        )
        allowed_suffixes = (
            {".pdf", ".png", ".jpg", ".jpeg", ".tif", ".tiff", ".webp"}
            if intent in {"invoice", "image_caption"}
            else SUPPORTED_FORMATS
        )
        st.caption(
            "PDF or image · maximum 50 MiB"
            if intent in {"invoice", "image_caption"}
            else "PDF, Office, CSV, TXT, Markdown, or image · maximum 50 MiB"
        )
        if intent in {"invoice", "image_caption"}:
            from document_processing.vintern_processor import resolve_vintern_python

            if resolve_vintern_python() is None:
                st.warning(
                    "Vintern runtime is not configured. Create .venv-vintern or set "
                    "DOCUMENT_PROCESSING_VINTERN_PYTHON; setup steps are in "
                    "src/document_processing/README.md."
                )
        uploaded = st.file_uploader(
            "Choose a file",
            type=sorted(suffix.lstrip(".") for suffix in allowed_suffixes),
            label_visibility="collapsed",
        )
        if uploaded is not None:
            content = uploaded.getvalue()
            st.caption(f"Selected: **{Path(uploaded.name).name}** · {len(content) / 1024:,.1f} KB")
            selected_pages = None
            page_selection_error = None
            if Path(uploaded.name).suffix.lower() == ".pdf":
                try:
                    pdf_pages = _pdf_page_count(content)
                    if pdf_pages < 1:
                        raise ValueError("The PDF has no pages.")
                    page_selection = st.text_input(
                        "Pages to process",
                        placeholder="2, 5, 9 (leave blank to process all pages)",
                        key=f"upload_pdf_pages_{hashlib.sha256(content).hexdigest()[:12]}",
                    )
                    selected_pages = _parse_selected_pages(page_selection, pdf_pages)
                    st.caption(
                        f"PDF has {pdf_pages} pages. Choose any pages with commas; blank means all pages."
                    )
                except Exception as error:
                    page_selection_error = str(error)
                    st.warning(f"Could not use this page selection: {error}")
            if st.button("Process and save", type="primary", use_container_width=True):
                if len(content) > MAX_UPLOAD_BYTES:
                    st.error("The document exceeds the 50 MiB limit.")
                elif page_selection_error is not None:
                    st.error(page_selection_error)
                else:
                    spinner = (
                        "Extracting invoice fields with Vintern…"
                        if intent == "invoice"
                        else "Writing an image caption with Vintern…"
                        if intent == "image_caption"
                        else "Processing document with Docling…"
                    )
                    with st.spinner(spinner):
                        try:
                            st.session_state["latest_run"] = _process_upload(
                                Path(uploaded.name).name,
                                content,
                                intent=intent,
                                ocr_engine=ocr_engine,
                                language=language,
                                device=device,
                                ocr_enabled=ocr_enabled,
                                table_structure=table_structure,
                                chart_recognition=chart_recognition,
                                num_threads=int(num_threads),
                                selected_pages=selected_pages,
                            )
                        except Exception as error:
                            st.error(f"Could not process {Path(uploaded.name).name}.")
                            with st.expander("Technical details"):
                                st.exception(error)
                            st.stop()
                    st.success("Document processed and saved.")
        else:
            st.info("Choose a document to begin processing.")

st.divider()
runs = _load_runs()
st.subheader("Saved documents")
if not runs:
    st.info(f"No saved documents yet. Results will be stored locally in `{STORE_DIR}`.")
else:
    st.caption(f"{len(runs):,} saved document{'s' if len(runs) != 1 else ''} · stored locally")
    labels = {
        run["run_id"]: f'{run["filename"]} · {run["processed_at"][:19].replace("T", " ")}'
        for run in runs
    }
    selected_id = st.selectbox("Select a document", labels, format_func=labels.__getitem__)
    selected_manifest = next(run for run in runs if run["run_id"] == selected_id)
    try:
        selected_output_path = STORE_DIR / selected_id / "output.json"
        selected_output_text = selected_output_path.read_text(encoding="utf-8")
        selected_output = _normalize_saved_output(json.loads(selected_output_text))
        selected_output_text = json.dumps(selected_output, ensure_ascii=False, indent=2, default=str)
    except (OSError, json.JSONDecodeError, KeyError) as error:
        st.error(f"Could not open this saved result: {error}")
    else:
        elements = selected_output.get("elements", [])
        raw_text = "\n\n".join(
            str(element.get("text") or "").strip()
            for element in elements
            if str(element.get("text") or "").strip()
        )
        metric_columns = st.columns([1, 1, 2, 2])
        metric_columns[0].metric("Elements", f'{selected_manifest["element_count"]:,}')
        metric_columns[1].metric("Tables", f'{selected_manifest["table_count"]:,}')
        metric_columns[2].download_button(
            "Download raw text",
            raw_text,
            file_name=f'{Path(selected_manifest["filename"]).stem}.txt',
            mime="text/plain; charset=utf-8",
            disabled=not raw_text,
            use_container_width=True,
        )
        metric_columns[3].download_button(
            "Download parser output JSON",
            selected_output_text,
            file_name=f'{selected_manifest["filename"]}.docling.json',
            mime="application/json",
            use_container_width=True,
        )
        if st.button(
            "Upload parser output to Supabase (no chunking)",
            key=f"upload-parser-output-{selected_id}",
            help="Save the parser's ordered elements and structured tables. No chunks or embeddings are created.",
        ):
            from dotenv import load_dotenv

            load_dotenv(Path(__file__).resolve().parents[2] / ".env")
            repository = None
            try:
                from core.database.document_processing_output_repository import DocumentProcessingOutputRepository

                repository = DocumentProcessingOutputRepository()
                parser_metadata = selected_output.get("metadata") or {}
                document_id = f"PARSER-{selected_id}"
                element_count, table_count = repository.save_parser_output(
                    document_id=document_id,
                    title=Path(selected_manifest["filename"]).stem,
                    file_format=Path(selected_manifest["filename"]).suffix.lstrip(".").upper(),
                    source_sha256=selected_manifest["source_sha256"],
                    pipeline_id=str(parser_metadata.get("pipeline_id") or parser_metadata.get("parser_engine") or "docling"),
                    elements=elements,
                    tables=selected_output.get("tables", []),
                    document_metadata={
                        **parser_metadata,
                        "filename": selected_manifest["filename"],
                        "source_sha256": selected_manifest["source_sha256"],
                        "local_parser_run_id": selected_id,
                        "chunking_applied": False,
                        "embeddings_created": False,
                    },
                )
                st.success(
                    f"Saved {element_count:,} parser elements and {table_count:,} structured tables to Supabase · {document_id} · no chunks or embeddings created."
                )
            except Exception as error:
                st.error(f"Supabase parser-output upload failed: {error}")
            finally:
                if repository is not None:
                    repository.close()

        run_dir = STORE_DIR / selected_id
        source_path = run_dir / "source"
        page_tab, extraction_tab, raw_tab, tables_tab, handoff_tab, details_tab, supabase_tab = st.tabs(
            ["Page review", "Invoice / caption", "Raw text", "Tables", "Text elements", "Run details", "Supabase row preview"]
        )
        with page_tab:
            page_numbers = _page_numbers(run_dir) if source_path.is_file() else []
            if page_numbers:
                page_number = st.selectbox(
                    "Page",
                    page_numbers,
                    format_func=lambda number: f"Page {number}",
                )
                if (
                    len(page_numbers) == 1
                    and Path(selected_manifest["filename"]).suffix.lower() in {".png", ".jpg", ".jpeg", ".tif", ".tiff"}
                ):
                    page_elements = elements
                    page_tables = selected_output.get("tables", [])
                else:
                    page_elements = [
                        element for element in elements
                        if (element.get("metadata") or {}).get("page_number") is not None
                        and int(element["metadata"]["page_number"]) == page_number
                    ]
                    page_tables = []
                    for table in selected_output.get("tables", []):
                        table_page = table.get("page_number")
                        if table_page is None:
                            table_page = (table.get("metadata") or {}).get("page_number")
                        if table_page is not None and int(table_page) == page_number:
                            page_tables.append(table)

                raw_column, extracted_column = st.columns(2, gap="large")
                with raw_column:
                    with st.container(border=True):
                        st.subheader(f"Page preview · {page_number}")
                        preview = _page_preview(run_dir, page_number)
                        if preview is not None:
                            show_boxes = st.checkbox("Show bounding boxes", value=True)
                            show_raw_layout = st.checkbox("Show raw PP-DocLayoutV3 labels", value=False)
                            if show_boxes or show_raw_layout:
                                page_sizes = selected_output.get("page_sizes") or {}
                                preview = _page_preview_with_boxes(
                                    preview,
                                    page_elements if show_boxes else [],
                                    page_tables if show_boxes else [],
                                    page_sizes.get(str(page_number)),
                                    default_origin=(
                                        "BOTTOMLEFT"
                                        if Path(selected_manifest["filename"]).suffix.lower() == ".pdf"
                                        else "TOPLEFT"
                                    ),
                                    layout_detections=[
                                        detection for detection in selected_output.get("layout_detections", [])
                                        if int(detection.get("page_number", -1)) == page_number
                                    ] if show_raw_layout else [],
                                )
                            st.image(preview, use_container_width=True)
                        else:
                            st.info("Source page preview is not available for this file.")
                with extracted_column:
                    with st.container(border=True):
                        st.subheader("Extracted output")
                        st.caption(f"{len(page_elements):,} elements · {len(page_tables):,} tables")
                        page_layout_detections = [
                            detection for detection in selected_output.get("layout_detections", [])
                            if int(detection.get("page_number", -1)) == page_number
                        ]
                        title_links = [
                            {
                                "title text": item.get("associated_title_text") or "(no OCR text in title box)",
                                "matched region": (
                                    f"{item['associated_target']['target_type']} "
                                    f"#{item['associated_target']['target_index']}"
                                ),
                                "layout label": item.get("label"),
                                "distance": item["associated_target"].get("distance_score"),
                            }
                            for item in page_layout_detections
                            if item.get("associated_target")
                        ]
                        if title_links:
                            st.markdown("**Title ↔ table/chart matches** · geometric heuristic")
                            st.dataframe(title_links, hide_index=True, use_container_width=True)
                        if page_layout_detections:
                            from collections import Counter

                            with st.expander(f"Raw PP-DocLayoutV3 labels · {len(page_layout_detections)} detections"):
                                counts = Counter(item["label"] for item in page_layout_detections)
                                st.write(dict(sorted(counts.items())))
                                st.dataframe([
                                    {
                                        "source_label": item["label"],
                                        "score": item["score"],
                                        "bbox": item["bbox"],
                                        "matched_object": item.get("associated_target"),
                                        "matched_title_text": item.get("associated_title_text"),
                                    }
                                    for item in page_layout_detections
                                ], hide_index=True, use_container_width=True)
                        if not page_elements:
                            st.info("No document elements were extracted from this page.")
                        for index, element in enumerate(page_elements, 1):
                            metadata = element.get("metadata", {})
                            element_type = normalize_element_label(
                                metadata.get("element_type") or metadata.get("layout_type") or metadata.get("docling_label")
                            )
                            st.markdown(f"**Element {index} · {element_type}**")
                            st.text(element.get("text") or "[Table reference]")
                        for index, table in enumerate(page_tables, 1):
                            st.markdown(f"**{_table_display_name(table, index)}**")
                            st.dataframe(table.get("rows", []), hide_index=True, use_container_width=True)
            else:
                st.info("This file type has no page preview. Download the original file from Run details.")
                if elements:
                    st.subheader("Extracted output")
                    for index, element in enumerate(elements, 1):
                        metadata = element.get("metadata", {})
                        element_type = normalize_element_label(
                            metadata.get("element_type")
                            or metadata.get("layout_type")
                            or metadata.get("docling_label")
                        )
                        st.markdown(f"**Element {index} · {element_type}**")
                        st.text(element.get("text") or "[Table reference]")
        with extraction_tab:
            extraction = selected_output.get("invoice_extraction")
            caption = selected_output.get("image_caption_extraction")
            if caption:
                st.caption(f"Model: {caption.get('model', 'unknown')} · status: {caption.get('status', 'unknown')}")
                for page in caption.get("pages", []):
                    st.subheader(f"Page {page.get('page_number', '?')}")
                    st.write(page.get("caption") or "No caption was generated.")
                    with st.expander("Raw model response"):
                        st.code(page.get("raw_response", ""), language="text", wrap_lines=True)
            elif not extraction:
                st.info("This run used the general document pipeline, not invoice extraction.")
            else:
                st.warning("Draft extraction: verify every field against the source invoice before use.")
                st.caption(f"Model: {extraction.get('model', 'unknown')} · status: {extraction.get('status', 'unknown')}")
                for page in extraction.get("pages", []):
                    st.subheader(f"Page {page.get('page_number', '?')}")
                    if page.get("fields") is not None:
                        st.json(page["fields"])
                    else:
                        st.error("The model response could not be parsed as an object; inspect the raw response.")
                    with st.expander("Raw model response"):
                        st.code(page.get("raw_response", ""), language="text", wrap_lines=True)
        with raw_tab:
            if raw_text:
                st.caption("Extracted text, in document reading order.")
                st.code(raw_text, language="text", wrap_lines=True)
            else:
                st.info("No raw text was extracted from this document.")
        with tables_tab:
            tables = selected_output.get("tables", [])
            if not tables:
                st.info("No structured tables were extracted.")
            for index, table in enumerate(tables, 1):
                st.markdown(f"**{_table_display_name(table, index)}**")
                st.dataframe(table.get("rows", []), hide_index=True, use_container_width=True)
        with handoff_tab:
            st.caption(
                "Inspect the ordered elements that will be passed to chunking."
            )
            furniture_elements = [
                element
                for element in elements
                if (element.get("metadata") or {}).get("element_type")
                in {"page_header", "page_footer"}
            ]
            if furniture_elements:
                st.markdown("**Page headers and footers**")
                for element in furniture_elements:
                    element_type = element["metadata"]["element_type"]
                    st.markdown(f"**{element_type}** · {element.get('text') or '[No text]'}")
            else:
                st.caption("No page_header or page_footer elements in this saved run.")
            page_numbers = sorted({
                int(element["metadata"]["page_number"])
                for element in elements
                if (element.get("metadata") or {}).get("page_number") is not None
            })
            if page_numbers:
                handoff_page = st.selectbox(
                    "Parser data page",
                    page_numbers,
                    index=page_numbers.index(26) if 26 in page_numbers else 0,
                    format_func=lambda number: f"Page {number}",
                    key="handoff_page",
                )
                page_elements = [
                    element for element in elements
                    if (element.get("metadata") or {}).get("page_number") == handoff_page
                ]
                st.caption(f"{len(page_elements)} ordered elements on this page.")
                st.json(page_elements, expanded=True)
            else:
                st.caption("This format has no page numbers, so all ordered elements are shown.")
                st.json(elements, expanded=True)
        with supabase_tab:
            output_row = _parser_output_row_preview(
                selected_id,
                selected_manifest["filename"],
                selected_manifest["source_sha256"],
                selected_output,
            )
            st.caption(
                "Local preview only. Nothing is read from or written to Supabase in this tab. "
                "Use the upload button above when you are ready."
            )
            st.json({key: value for key, value in output_row.items() if key not in {
                "elements", "tables", "document_metadata",
            }})
            for column_name in ("elements", "tables", "document_metadata"):
                value = output_row[column_name]
                item_count = len(value) if isinstance(value, list) else None
                suffix = f" · {item_count} items" if item_count is not None else ""
                with st.expander(f"{column_name}{suffix}"):
                    st.json(value)
            st.download_button(
                "Download local row preview as JSON",
                json.dumps(output_row, ensure_ascii=False, indent=2, default=str),
                file_name=f"{output_row['document_id']}-document_processing_outputs-preview.json",
                mime="application/json",
                key=f"download-local-row-preview-{selected_id}",
            )

        with details_tab:
            run_config = selected_manifest.get("config") or {}
            output_metadata = selected_output.get("metadata") or {}
            if run_config.get("intent", "document") in {"invoice", "image_caption"}:
                intent_label = "Invoice extraction" if run_config["intent"] == "invoice" else "Image caption"
                pipeline_id = output_metadata.get("pipeline_id") or f"vintern_{run_config['intent']}"
                st.write(f"**Intent:** {intent_label}")
                st.write(f"**Pipeline:** {pipeline_id}")
            source_suffix = Path(selected_manifest["filename"]).suffix.lower()
            uses_pdf_pipeline = source_suffix in {".pdf", ".png", ".jpg", ".jpeg", ".tif", ".tiff"}
            effective_ocr = output_metadata.get("ocr_enabled", run_config.get("docling_ocr", True))
            embedded_image_ocr = output_metadata.get("embedded_image_ocr_enabled", False)
            ocr_engine = run_config.get("docling_ocr_engine", "tesseract")
            ocr_model_name = (
                "VietOCR vgg_seq2seq (greedy, 512 px)"
                if ocr_engine == "vietocr"
                else f"Tesseract (language: {run_config.get('docling_ocr_language', 'vie')}, PSM 6)"
            )
            if uses_pdf_pipeline:
                layout_model = output_metadata.get(
                    "layout_model",
                    run_config.get(
                        "docling_layout_model",
                        "Docling Heron (`docling-project/docling-layout-heron`)",
                    ),
                )
                table_recognition_model = (
                    "Docling TableFormer (Accurate, cell matching)"
                    if run_config.get("docling_table_structure", True)
                    else "Disabled"
                )
                if embedded_image_ocr and not effective_ocr:
                    text_recognition_model = f"{ocr_model_name} (embedded images only)"
                elif not effective_ocr:
                    text_recognition_model = "OCR disabled"
                else:
                    text_recognition_model = ocr_model_name
            else:
                text_recognition_model = "Docling native text extraction (no OCR model)"
                layout_model = "Docling native document structure (no page layout model)"
                table_recognition_model = "Docling native table extraction"
                if embedded_image_ocr:
                    text_recognition_model = f"{ocr_model_name} (embedded images only)"
            st.write(f'**File:** {selected_manifest["filename"]}')
            st.write(f'**Processed:** {selected_manifest["processed_at"][:19].replace("T", " ")} UTC')
            if source_suffix == ".pdf":
                selected_source_pages = run_config.get("selected_source_pages")
                page_selection_label = (
                    f"**PDF pages processed:** {', '.join(map(str, selected_source_pages))}"
                    if selected_source_pages else "**PDF pages processed:** all pages"
                )
                st.write(page_selection_label)
            st.write(f'**Parser:** {selected_manifest.get("config", {}).get("parser_engine", "docling")}')
            if output_metadata.get("pdf_processing_route"):
                st.write(f'**PDF route:** {output_metadata["pdf_processing_route"]}')
            st.write(f"**Text recognition model:** {text_recognition_model}")
            st.write(f"**Layout model:** {layout_model}")
            st.write(f"**Table recognition model:** {table_recognition_model}")
            st.write(f'**SHA-256:** `{selected_manifest["source_sha256"]}`')
            if source_path.is_file():
                st.download_button(
                    "Download original file",
                    source_path.read_bytes(),
                    file_name=selected_manifest["filename"],
                    mime="application/octet-stream",
                )
            parser_metadata = selected_output.get("metadata", {})
            routing_diagnostics = parser_metadata.get("ocr_routing_diagnostics", [])
            orientation_diagnostics = parser_metadata.get("ocr_orientation_diagnostics", [])
            if routing_diagnostics:
                with st.expander(f"OCR diagnostics · {len(routing_diagnostics)} lines"):
                    routing_log = "".join(
                        json.dumps(item, ensure_ascii=False, separators=(",", ":")) + "\n"
                        for item in routing_diagnostics
                    )
                    st.download_button(
                        "Download OCR routing log (.jsonl)",
                        routing_log,
                        file_name=f'{Path(selected_manifest["filename"]).stem}.ocr-routing.jsonl',
                        mime="application/x-ndjson",
                        key=f"download-ocr-routing-{selected_id}",
                    )
                    st.dataframe(routing_diagnostics, use_container_width=True, hide_index=True)
                    if orientation_diagnostics:
                        st.caption("Layout-region orientation decisions")
                        st.dataframe(
                            orientation_diagnostics, use_container_width=True, hide_index=True
                        )
            st.json(parser_metadata)
